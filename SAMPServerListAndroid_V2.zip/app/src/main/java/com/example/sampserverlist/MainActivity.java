package com.example.sampserverlist;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(18, 18, 18);
    private static final int PANEL = Color.rgb(34, 34, 34);
    private static final int ORANGE = Color.rgb(255, 128, 0);
    private final ArrayList<Server> servers = new ArrayList<>();
    private LinearLayout listContainer;
    private SharedPreferences prefs;

    static class Server {
        String name, ip, port;
        Server(String n, String i, String p) { name=n; ip=i; port=p; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("servers", MODE_PRIVATE);
        loadServers();
        buildScreen();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ORANGE));
        return b;
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(14), dp(18), dp(14), dp(12));

        TextView title = text("SAMP SERVER LIST", 23, ORANGE);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = text("Seus servidores SA-MP em um só lugar", 13, Color.LTGRAY);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.bottomMargin = dp(12);
        root.addView(subtitle, sp);

        Button add = button("+ ADICIONAR SERVIDOR");
        add.setOnClickListener(v -> showServerDialog(-1));
        root.addView(add, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1);
        lp.topMargin = dp(12);
        root.addView(scroll, lp);
        scroll.addView(listContainer);

        setContentView(root);
        renderServers();
    }

    private void renderServers() {
        listContainer.removeAllViews();
        if (servers.isEmpty()) {
            TextView empty = text("Nenhum servidor cadastrado.\nToque em ADICIONAR SERVIDOR para começar.", 15, Color.LTGRAY);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(12), dp(30), dp(12), dp(30));
            listContainer.addView(empty);
            return;
        }
        for (int index=0; index<servers.size(); index++) {
            final int pos = index;
            Server s = servers.get(index);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundTintList(null);
            card.setBackgroundColor(PANEL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = dp(10);
            listContainer.addView(card, cp);

            TextView name = text(s.name, 18, ORANGE);
            name.setTypeface(null, Typeface.BOLD);
            card.addView(name);
            TextView address = text(s.ip + ":" + s.port, 14, Color.WHITE);
            card.addView(address);

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            Button connect = button("CONECTAR");
            Button edit = button("EDITAR");
            Button delete = button("EXCLUIR");
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, -2, 1);
            ap.topMargin = dp(6);
            ap.rightMargin = dp(4);
            actions.addView(connect, ap);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, -2, 1);
            bp.topMargin = dp(6); bp.rightMargin = dp(4);
            actions.addView(edit, bp);
            LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(0, -2, 1);
            dp2.topMargin = dp(6);
            actions.addView(delete, dp2);
            card.addView(actions);

            connect.setOnClickListener(v -> connectTo(s));
            edit.setOnClickListener(v -> showServerDialog(pos));
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Excluir servidor?")
                .setMessage("Deseja remover " + s.name + "?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (d,w) -> { servers.remove(pos); saveServers(); renderServers(); })
                .show());
        }
    }

    private void showServerDialog(int position) {
        boolean editing = position >= 0;
        Server old = editing ? servers.get(position) : null;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(8), dp(18), 0);

        EditText name = field("Nome do servidor");
        EditText ip = field("IP ou endereço");
        EditText port = field("Porta (padrão 7777)");
        if (editing) { name.setText(old.name); ip.setText(old.ip); port.setText(old.port); }
        form.addView(name); form.addView(ip); form.addView(port);

        new AlertDialog.Builder(this)
            .setTitle(editing ? "Editar servidor" : "Novo servidor")
            .setView(form)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar", (dialog, which) -> {
                String n=name.getText().toString().trim();
                String i=ip.getText().toString().trim();
                String p=port.getText().toString().trim();
                if (n.isEmpty() || i.isEmpty()) {
                    Toast.makeText(this, "Informe o nome e o IP.", Toast.LENGTH_LONG).show();
                    return;
                }
                if (p.isEmpty()) p="7777";
                if (editing) servers.set(position, new Server(n,i,p));
                else servers.add(new Server(n,i,p));
                saveServers(); renderServers();
            }).show();
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY);
        e.setHint(hint);
        return e;
    }

    private void connectTo(Server s) {
        String address = "samp://" + s.ip + ":" + s.port;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(address));
            startActivity(intent);
        } catch (Exception ex) {
            Toast.makeText(this, "Não encontrei um cliente SA-MP compatível para abrir esse endereço.", Toast.LENGTH_LONG).show();
        }
    }

    private void saveServers() {
        JSONArray array = new JSONArray();
        try {
            for (Server s : servers) {
                JSONObject o = new JSONObject();
                o.put("name", s.name); o.put("ip", s.ip); o.put("port", s.port);
                array.put(o);
            }
            prefs.edit().putString("items", array.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void loadServers() {
        String raw = prefs.getString("items", "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i=0; i<array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                servers.add(new Server(o.optString("name"), o.optString("ip"), o.optString("port", "7777")));
            }
        } catch (Exception ignored) { }
    }
}
